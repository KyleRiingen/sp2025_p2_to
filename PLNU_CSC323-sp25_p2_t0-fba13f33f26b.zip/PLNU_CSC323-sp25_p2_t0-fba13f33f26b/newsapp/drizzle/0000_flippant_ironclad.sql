-- Current sql file was generated after introspecting the database
-- If you want to run this migration please uncomment this code before executing migrations
/*
CREATE TABLE "articles" (
	"id" serial PRIMARY KEY NOT NULL,
	"articleName" varchar(255) NOT NULL,
	"link" varchar(255) NOT NULL,
	"newsSource" varchar(255) NOT NULL,
	"content" text,
	"author" varchar
);

*/